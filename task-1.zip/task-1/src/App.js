
import './App.css';
import React from "react"
import Counter from './Components/Counter';

function App() {
  return (
    <div className="App">
      <h1>counter</h1>
     <Counter/>
    </div>
  );
}

export default App;
